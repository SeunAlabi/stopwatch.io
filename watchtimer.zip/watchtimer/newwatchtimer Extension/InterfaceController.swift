//
//  InterfaceController.swift
//  newwatchtimer Extension
//
//  Created by Seun Alabi on 08.01.19.
//  Copyright © 2019 Seun Alabi. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var lblCounter: WKInterfaceLabel!
    
    var counter: Int!
    var timer: Timer!
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        counter = 1
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(InterfaceController.updateTimer), userInfo: nil, repeats: true)
        // Configure interface objects here.
    }
    
    func updateTimer(){
        counter = counter + 1
        if (counter < 11)
        {
            lblCounter.setText(String(counter))
        }
        else
        {
            if (timer != nil){
                timer.invalidate()
            }
            timer = nil
            counter = 1
            lblCounter.setText(String(counter))
        }
        
        
        }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func stop() {
        if (timer != nil){
            timer.invalidate()
        }
        timer = nil
        counter = 1
    }
    @IBAction func start() {
        
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(InterfaceController.updateTimer), userInfo: nil, repeats: true)    }
}
